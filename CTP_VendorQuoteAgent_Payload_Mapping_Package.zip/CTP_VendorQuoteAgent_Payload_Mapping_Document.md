# CTP Vendor Quote Agent Payload Mapping Document

Knowledge-ready instructions for Copilot Studio payload generation.

## 1. Purpose
This document tells the CTP Vendor Quote Agent exactly how to create a clean, flow-ready payload from a vendor quote document. The payload should create one parent Vendor Quote Staging record and one Vendor Quote Line Staging record per extracted product line. It should not create Opportunity Product Lines directly.

| Item | Value |
|---|---|
| Environment URL | https://org4d693c12.crm.dynamics.com/ |
| Solution | ctp_VendorQuoteAutomation |
| Publisher | CTP Solutions |
| Prefix | ctp |
| Parent table | ctp_vendorquotestaging |
| Child line table | ctp_vendorquotelinestaging |
| Final destination after approval | opportunityproduct |

## 2. Golden Rules for the Agent
- Always create staging first. Never create Opportunity Product Lines directly from the extracted document payload.
- The Opportunity lookup must be a Dataverse Opportunity GUID. Do not put the Opportunity name in ctp_opportunity.
- Choice fields must use the numeric Dataverse option value in the normalized payload.
- Lookup fields must use Dataverse row IDs/GUIDs, not display names.
- After extraction, unmatched lines must stay Unmatched and ctp_usewriteinproduct must be false until the user approves write-in handling.
- If DOCX is detected, map file type to Unknown unless a DOCX option is added to ctp_filetype.
- Do not include ctp_category as a Dataverse field because it does not exist in the current table attributes. Store category under metadata only.
- Do not store the full large extraction payload in ctp_jsonpayload if it exceeds 2000 characters. Store a compact header summary.
- Final parent status after all line staging records are created should be Requires Review if any line is unmatched or low confidence.
- Vendor cost must remain separate from sell price. Do not populate native priceperunit from vendor cost unless a later approved business rule says to do so.

## 3. Canonical Payload Shape
```json
{
  "payload_version": "1.0",
  "source_system": "CTP Vendor Quote Agent",
  "target_flow": "CTP_CreateVendorQuoteStagingFromPayload",
  "ctp_vendorquotestaging": {
    "ctp_newcolumn": "<batch display name>",
    "ctp_filename": "<file name, max 100>",
    "ctp_filetype": 961490004,
    "ctp_fileurl": "<file reference or URL, max 100 unless field is increased>",
    "ctp_opportunity": "<opportunity-guid>",
    "ctp_status": 961490001,
    "ctp_processingrunid": "<run id, max 100>",
    "ctp_processedon": "<UTC ISO datetime>",
    "ctp_totallines": 0,
    "ctp_matchedlines": 0,
    "ctp_unmatchedlines": 0,
    "ctp_errormessage": "<summary message, max 2000>",
    "ctp_jsonpayload": "<compact escaped JSON string, max 2000>"
  },
  "ctp_vendorquotelinestaging": [
    {
      "ctp_newcolumn": "Line 1 - <short product name>",
      "ctp_linenumber": 1,
      "ctp_productidsku": null,
      "ctp_productname": "<product name, max 100>",
      "ctp_description": "<full extracted description, max 2000>",
      "ctp_finaldescription": "<cleaned description, max 2000>",
      "ctp_quantity": 1,
      "ctp_unitofmeasure": "EA",
      "ctp_vendorunitcost": null,
      "ctp_vendorextendedcost": null,
      "ctp_matchedproduct": null,
      "ctp_matchstatus": 961490001,
      "ctp_matchconfidence": null,
      "ctp_usewriteinproduct": false,
      "ctp_errormessage": "No SKU available. Awaiting description-based match by flow.",
      "metadata": {
        "category": "Services or UPS, not mapped to Dataverse unless field is created"
      }
    }
  ]
}
```

## 4. Parent Record Mapping: ctp_vendorquotestaging
| Dataverse Field | Type | Requirement | Agent Mapping Rule |
|---|---|---|---|
| ctp_newcolumn | Text | Required by agent | Batch display name. Use: <solution/opportunity> - <vendor> - <yyyyMMdd>. Max 850. |
| ctp_filename | Text | Required | Original file name. Max 100. |
| ctp_filetype | Choice | Required | Use numeric option value. DOCX currently maps to Unknown = 961490004. |
| ctp_fileurl | Text | Recommended | File ID, short link, or URL. Current max length is 100; increase field if storing full SharePoint URL. |
| ctp_opportunity | Lookup to opportunity | Required | Must be Opportunity GUID, not name. |
| ctp_status | Choice | Required | Create parent as Processing = 961490001, then update to Requires Review = 961490002 if any exceptions exist. |
| ctp_processingrunid | Text | Recommended | Unique run ID. Max 100. |
| ctp_processedon | DateTime | Recommended | UTC ISO timestamp. Example: 2026-06-26T18:30:00Z. |
| ctp_totallines | Whole number | Required | Count of extracted line items. |
| ctp_matchedlines | Whole number | Required | Count of lines matched to D365 Product. |
| ctp_unmatchedlines | Whole number | Required | Count of unmatched/low-confidence lines requiring review. |
| ctp_errormessage | Multiline text | Optional | Short processing/review summary. Max 2000. |
| ctp_jsonpayload | Multiline text | Optional | Compact header JSON string only. Max 2000. Do not store full line array here. |

## 5. Line Record Mapping: ctp_vendorquotelinestaging
| Dataverse Field | Type | Requirement | Agent Mapping Rule |
|---|---|---|---|
| ctp_newcolumn | Text | Required by agent | Line display name. Use: Line <n> - <short product name>. Max 850. |
| ctp_parentstaging | Lookup to ctp_vendorquotestaging | Required by flow | Flow must set this to the created parent staging GUID. Agent should not guess it. |
| ctp_linenumber | Whole number | Required | 1-based line number from the source document. |
| ctp_productidsku | Text | Optional | Vendor SKU or item number. Max 100. If extracted value is clearly not a SKU, set null and explain in ctp_errormessage. |
| ctp_productname | Text | Required if available | Short product name. Max 100. Put longer text in description fields. |
| ctp_description | Multiline text | Recommended | Raw extracted description. Max 2000. |
| ctp_finaldescription | Multiline text | Recommended | Cleaned human-readable description. Max 2000. |
| ctp_quantity | Decimal | Required | Quantity. Must be numeric. Default to 1 only when clearly implied. |
| ctp_unitofmeasure | Text | Optional | Use EA if unit is not found and business accepts default. Max 100. |
| ctp_vendorunitcost | Currency | Optional | Vendor unit cost if found. Use null if not present. |
| ctp_vendorextendedcost | Currency | Optional | Quantity x unit cost if both exist. Use null if not present. |
| ctp_matchedproduct | Lookup to product | Optional | Must be Product GUID if matched. Use null if not confidently matched. |
| ctp_matchstatus | Choice | Required | Use numeric option value. Use Unmatched = 961490001 after extraction unless a product match is confirmed. |
| ctp_matchconfidence | Decimal | Optional | 0-100 score if matching logic calculates one; otherwise null. |
| ctp_usewriteinproduct | Two options | Required | false after extraction. Set true only after user approves Write-In. |
| ctp_opportunityproduct | Lookup to opportunityproduct | Set after final creation | Leave null during extraction. Creation flow populates it after Opportunity Product is created. |
| ctp_errormessage | Multiline text | Optional | Line-level issue or review note. Max 2000. |

## 6. Choice Value Mapping
| Field | Label | Value | When to Use |
|---|---|---:|---|
| ctp_filetype | Excel | 961490001 | Use for .xlsx/.xls extracted as spreadsheet. |
| ctp_filetype | PDF | 961490002 | Use for .pdf. |
| ctp_filetype | Unsupported | 961490003 | Use when file cannot be processed. |
| ctp_filetype | Unknown | 961490004 | Use for .docx until DOCX is added as a choice. |
| ctp_status | Pending | 961490000 | Before processing starts. |
| ctp_status | Processing | 961490001 | While creating parent/line staging. |
| ctp_status | Requires Review | 961490002 | Use after staging if any line is Unmatched/Low Confidence/missing cost/missing product. |
| ctp_status | Ready for Approval | 961490003 | Use after staging if all lines are matched or explicitly resolved. |
| ctp_status | Approved | 961490004 | Only after user approves final creation. |
| ctp_status | Opportunity Products Created | 961490005 | After final opportunityproduct rows are created. |
| ctp_status | Failed | 961490006 | If flow/extraction fails. |
| ctp_status | Cancelled | 961490007 | If user cancels. |
| ctp_matchstatus | Matched | 961490000 | Use only when ctp_matchedproduct has a Product GUID. |
| ctp_matchstatus | Unmatched | 961490001 | Default for no confirmed product match. |
| ctp_matchstatus | Low Confidence | 961490002 | Use when possible match needs user review. |
| ctp_matchstatus | Write-In | 961490003 | Use only after user approves write-in. |
| ctp_matchstatus | Skipped | 961490004 | Use only after user chooses to skip line. |

## 7. Lookup Resolution Rules
| Lookup Field | Target Table | Rule |
|---|---|---|
| ctp_opportunity | opportunity | Must be an Opportunity GUID. If agent only knows name, call CTP_GetOpportunitySummary or search Opportunity first. |
| ctp_matchedproduct | product | Must be Product GUID. Only set when exact or approved product match exists. |
| ctp_parentstaging | ctp_vendorquotestaging | Set by the flow after parent staging row is created. |
| ctp_opportunityproduct | opportunityproduct | Set by final creation flow after Opportunity Line is created. Leave null in extraction payload. |
| ctp_sourcevendorquotestaging | ctp_vendorquotestaging | Used later on opportunityproduct after creation. |
| ctp_sourcevendorquoteline | ctp_vendorquotelinestaging | Used later on opportunityproduct after creation. |

## 8. Validation Checklist Before Sending Payload to Flow
- Payload has exactly one ctp_vendorquotestaging object.
- Payload has ctp_vendorquotelinestaging as an array, even when only one line exists.
- ctp_opportunity is a GUID, not the opportunity name.
- All choice fields are numeric Dataverse option values, not labels.
- All lookup fields are GUIDs or null.
- No ctp_category field is placed directly on Dataverse objects.
- ctp_jsonpayload is a string and is 2000 characters or fewer.
- ctp_fileurl is 100 characters or fewer unless the field has been increased.
- ctp_filename, ctp_productidsku, ctp_productname, and ctp_vendorquotefileurl respect current max lengths.
- Unmatched lines have ctp_matchstatus = 961490001 and ctp_usewriteinproduct = false.
- No opportunityproduct rows are requested from this payload.
- Parent final status returned by the staging flow should be Requires Review if any line remains unmatched.

## 9. Corrected Sample Payload Based on UMC Discovery Ridge Quote
```json
{
  "payload_version": "1.0",
  "source_system": "CTP Vendor Quote Agent",
  "target_flow": "CTP_CreateVendorQuoteStagingFromPayload",
  "ctp_vendorquotestaging": {
    "ctp_newcolumn": "UMC Discovery Ridge - 100kW UPS - Schneider Electric - 20260626",
    "ctp_filename": "UMC Discovery Ridge 100kW UPS 5-28-26 1.docx",
    "ctp_filetype": 961490004,
    "ctp_fileurl": "104a28ae-9cdc-41ad-908b-806a012eadc0",
    "ctp_opportunity": "<OPPORTUNITY_GUID_FROM_FLOW_1>",
    "ctp_status": 961490001,
    "ctp_processingrunid": "PRN-20260626-183000-UMC001",
    "ctp_processedon": "2026-06-26T18:30:00Z",
    "ctp_totallines": 10,
    "ctp_matchedlines": 0,
    "ctp_unmatchedlines": 10,
    "ctp_errormessage": "No SKUs found in source document. All lines require description-based matching.",
    "ctp_jsonpayload": "{\"solution_name\":\"UMC Discovery Ridge - 100kW UPS\",\"solution_number\":\"ISX0002642109-0007\",\"vendor\":\"Schneider Electric IT Corporation\",\"total_discounted_price\":73235.12}"
  },
  "ctp_vendorquotelinestaging": [
    {
      "ctp_newcolumn": "Line 1 - Galaxy VS UPS 100kW 480V",
      "ctp_linenumber": 1,
      "ctp_productidsku": null,
      "ctp_productname": "Galaxy VS UPS 100kW 480V for External Batteries",
      "ctp_description": "Galaxy VS UPS 100kW 480V for External Batteries, Start-up 5x8",
      "ctp_finaldescription": "Galaxy VS UPS 100kW 480V for External Batteries Start-up 5x8",
      "ctp_quantity": 1,
      "ctp_unitofmeasure": "EA",
      "ctp_vendorunitcost": null,
      "ctp_vendorextendedcost": null,
      "ctp_matchedproduct": null,
      "ctp_matchstatus": 961490001,
      "ctp_matchconfidence": null,
      "ctp_usewriteinproduct": false,
      "ctp_errormessage": "No SKU available. Awaiting description-based match by flow.",
      "metadata": {
        "category": "Uninterruptible Power Supply (UPS)"
      }
    },
    {
      "ctp_newcolumn": "Line 9 - 1 Year 4HR 7x24 Response Upgrade",
      "ctp_linenumber": 9,
      "ctp_productidsku": null,
      "ctp_productname": "1 Year 4HR 7x24 Response Upgrade",
      "ctp_description": "1 Year 4HR 7X24 Response Upgrade to Factor Warranty or Existing Service Contract for 41 to 150 kVA",
      "ctp_finaldescription": "1 Year 4HR 7x24 Response Upgrade to Factory Warranty or Existing Service Contract for 41 to 150 kVA",
      "ctp_quantity": 1,
      "ctp_unitofmeasure": "EA",
      "ctp_vendorunitcost": null,
      "ctp_vendorextendedcost": null,
      "ctp_matchedproduct": null,
      "ctp_matchstatus": 961490001,
      "ctp_matchconfidence": null,
      "ctp_usewriteinproduct": false,
      "ctp_errormessage": "No SKU available. Awaiting description-based match by flow.",
      "metadata": {
        "category": "Services"
      }
    }
  ]
}
```

## 10. Recommended Copilot Studio Instruction Block
```text
When extracting a vendor quote document, produce a single JSON payload that follows the CTP Vendor Quote Agent Payload Mapping Document. Use actual Dataverse field names from the CTP tables. Choice fields must use numeric option values. Lookup fields must use GUIDs or null. Never put display names into lookup fields. Create staging data only; do not create Opportunity Product Lines until a user reviews and approves the staging batch. Set unmatched lines to ctp_matchstatus 961490001 and ctp_usewriteinproduct false. If a file is DOCX, use ctp_filetype 961490004 unless the DOCX choice has been added. Do not include ctp_category as a Dataverse field; put category in metadata only. Return only valid JSON with no commentary when calling the staging flow.
```

## 11. Known Field Limit Warnings
| Field | Current Limit | Recommendation |
|---|---|---|
| ctp_fileurl | Text max 100 | Full SharePoint URLs often exceed this. Use a short file ID/reference or increase the field length. |
| ctp_jsonpayload | Multiline max 2000 | Do not store full extraction JSON here. Store compact summary or save full JSON externally. |
| ctp_filename | Text max 100 | Truncate or store clean short name when file name is longer. |
| ctp_productname | Text max 100 | Use short name here; store long text in ctp_description/ctp_finaldescription. |
| ctp_vendorquotefileurl on opportunityproduct | Text max 100 | Same limitation as ctp_fileurl. Use short reference or increase field length. |

## 12. Expected Flow Result After This Payload
| Result | Expected Value |
|---|---|
| Vendor Quote Staging records created | 1 |
| Vendor Quote Line Staging records created | One per extracted product line |
| Opportunity Product Lines created | 0 at staging step |
| Final parent status after line creation | Requires Review if any line is unmatched/low confidence |
| Next step | User review, product matching, approval, then Opportunity Product creation |
